const App = () =>
          <p>Hello ReactJSasdas</p>;

export default App;