import React from 'react';
window.React = React;
import ReactDOM from 'react-dom';
import App from './App';

ReactDOM.render(<App/>, document.getElementById('react-app'))
